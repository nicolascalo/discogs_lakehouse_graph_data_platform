import logging
import json
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pathlib import Path


class JsonFormatter(logging.Formatter):
    def __init__(self, env: str, project: str, storage_type: str):
        super().__init__()
        self.env = env
        self.project = project
        self.storage_type = storage_type

    def format(self, record: logging.LogRecord) -> str:
        log_record = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "function": record.funcName,
            "storage_type": self.storage_type,
            "line": record.lineno,
            "message": record.getMessage(),
            "env": self.env,
            "project": self.project,
        }

        if record.exc_info:
            log_record["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_record)


def setup_logger(log_file_path: Path, env: str, project: str, storage_type:str) -> None:
    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.setLevel(logging.INFO)

    formatter = JsonFormatter(env, project,storage_type)

    file_handler = RotatingFileHandler(
        log_file_path,
        maxBytes=50 * 1024 * 1024,
        backupCount=5,
    )
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)